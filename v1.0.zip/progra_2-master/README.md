# progra_2
Aca van las cositas de progra

1 - como hacer push(subir lo que quieran subir): 
  Para add tienen que tirar cada archivo o en su defecto una carpeta.
  Para la rama, no pongan master pq esa seria la principal, creense una, onda scerfoglio, fparodi o salviolin.
  https://help.github.com/articles/adding-a-file-to-a-repository-using-the-command-line/
  
2 - para clonar el repositorio solo tienen que poner:
  git clone [link que les pase]
