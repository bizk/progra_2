
import api.*;
import utilidades.*;
import implementaciones.arreglos.*;

public class test {
	
	public static void main(String[] args) {
		PilaTDA p = new Pilas();
		ColaTDA c = new ColaPI();
				
		p.InicializarPila();
		p.Apilar(2);
		p.Apilar(3);
		System.out.println(p.Tope());
		p.Apilar(4);
		System.out.println(p.Tope());
		p.Desapilar();
		System.out.println(p.Tope());
	}
}